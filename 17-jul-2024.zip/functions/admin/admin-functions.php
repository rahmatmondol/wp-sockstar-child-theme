<?php
include_once get_stylesheet_directory() . '/functions/admin/custom-column.php'; //admin ajax
include_once get_stylesheet_directory() . '/functions/admin/meta-fields.php'; //admin ajax
include_once get_stylesheet_directory() . '/functions/admin/admin-scripts.php'; //admin scrpts all
include_once get_stylesheet_directory() . '/functions/admin/admin-menus.php'; //admin menu
include_once get_stylesheet_directory() . '/functions/admin/admin-ajax.php'; //admin ajax

