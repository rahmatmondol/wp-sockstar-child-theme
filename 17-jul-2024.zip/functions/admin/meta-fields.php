<?php
function add_user_status_field($user)
{
    $status = get_user_meta($user->ID, 'user_flag', true);
?>
    <h3>User Status</h3>
    <table class="form-table">
        <tr>
            <th><label for="user_flag">Status</label></th>
            <td>
                <select name="user_flag" id="user_flag">
                    <option value="active" <?php selected($status, 'active'); ?>>Active</option>
                    <option value="inactive" <?php selected($status, 'inactive'); ?>>Inactive</option>
                    <option value="declined" <?php selected($status, 'declined'); ?>>Declined</option>
                </select>
            </td>
        </tr>
    </table>
<?php
}
add_action('show_user_profile', 'add_user_status_field');
add_action('edit_user_profile', 'add_user_status_field');


function save_user_status_field($user_id) {
    // Check that the current user has the capability to edit the user.
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Update the user meta with the new status.
    update_user_meta($user_id, 'user_flag', $_POST['user_flag']);
}
add_action('personal_options_update', 'save_user_status_field');
add_action('edit_user_profile_update', 'save_user_status_field');
